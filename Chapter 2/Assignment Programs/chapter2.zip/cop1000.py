# Jonathan Loescher SPC ID: 2307132

# Pseudocode
# Print "Jonathan Loescher" and section number "24-LEC (447)".
# Print the term used for appending a string to another. Answer: Concatenate
# Print the term used for data encloded in single or double quotes. Answer: String
# Print the purpose of the ** operator in Python. Answer: Exponentiation
# Print the purpose of the end='' argument in a Python print function. Answer: It creates a space instead of a new line.

def main():
    print ("Jonathan Loescher, 24-LEC (447)") # Using print function to display data from strings.
    print ("The term used for appending one string to another is: ", "Concatenate") # Using concatination within print function to combine two strings and display the data to the end user.
    print ("The term used for data enclosed in single or double quotes is: ", "String")
    print ("The purpose of the ** operator in python is: ", "Exponentiation")
    print ("The purpose of the end='' argument in a Python print function is: ", "It creates a space instead of a new line.")

main()

# Collaboration Statement: I worked alone.
