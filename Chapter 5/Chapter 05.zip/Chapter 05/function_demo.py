# This program demonstrates a function.
# First, we define a function named message.
def message():
    print('I am Arthur')
    print('King of the Britons')

# Call the message function.
message()
