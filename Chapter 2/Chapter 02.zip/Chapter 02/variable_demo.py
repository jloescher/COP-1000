# This program demonstrates a variable.
room = 503
print('I am staying in room number')
print(room)
